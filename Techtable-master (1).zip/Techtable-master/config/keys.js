export const Keys = {
  CompanyName: 'Welcome to TechTables',
};
