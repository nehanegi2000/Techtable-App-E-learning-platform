# Techtable
Techtable app
just run npm install inside project to install node_modules
then run your project by "react-native run-android"
